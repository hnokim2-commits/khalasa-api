import crypto from 'node:crypto';
import { readFile } from 'node:fs/promises';

const [file] = process.argv.slice(2);
const passphrase = process.env.KHALASA_BACKUP_PASSPHRASE;
if (!file) throw new Error('Backup file path is required');
if (!passphrase) throw new Error('KHALASA_BACKUP_PASSPHRASE is required');
const envelope = JSON.parse(await readFile(file, 'utf8'));
if (envelope.format !== 'khalasa-encrypted-backup' || envelope.version !== 1) throw new Error('Unsupported backup format');
const key = crypto.scryptSync(passphrase, Buffer.from(envelope.salt, 'base64'), 32);
const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(envelope.iv, 'base64'));
decipher.setAuthTag(Buffer.from(envelope.tag, 'base64'));
const plaintext = Buffer.concat([decipher.update(Buffer.from(envelope.data, 'base64')), decipher.final()]);
const backup = JSON.parse(plaintext.toString('utf8'));
if (backup.format !== 'khalasa-manual-backup' || backup.version !== 1) throw new Error('Invalid decrypted backup');
console.log(`Backup verified: ${backup.createdAt}`);
console.log(`Tables: ${backup.tables.length}; rows: ${backup.tables.reduce((sum, table) => sum + table.rows.length, 0)}`);
console.log(`Migrations: ${backup.migrations.length}`);

